console.log("The End page loaded with animation");
